# SirioLibanesApp

[![CI Status](http://img.shields.io/travis/federico0812/SirioLibanesApp.svg?style=flat)](https://travis-ci.org/federico0812/SirioLibanesApp)
[![Version](https://img.shields.io/cocoapods/v/SirioLibanesApp.svg?style=flat)](http://cocoapods.org/pods/SirioLibanesApp)
[![License](https://img.shields.io/cocoapods/l/SirioLibanesApp.svg?style=flat)](http://cocoapods.org/pods/SirioLibanesApp)
[![Platform](https://img.shields.io/cocoapods/p/SirioLibanesApp.svg?style=flat)](http://cocoapods.org/pods/SirioLibanesApp)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

SirioLibanesApp is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'SirioLibanesApp'
```

## Author

federico0812, federico0812@gmail.com

## License

SirioLibanesApp is available under the MIT license. See the LICENSE file for more info.
